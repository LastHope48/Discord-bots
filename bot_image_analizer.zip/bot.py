import discord # Discord kütüphanesini import ettik
from colorama import Fore # Renkli yazı için gerekli olan modülü import ettik (opsiyonel)
from discord.ext import commands # Komutlar için gerekli olan modülü import ettik
import re
import random
from bot_mantık import secret_function,emoji,get_panda_image_url,get_cat_image_url,get_dog_image_url,get_duck_image_url,gen_pass
import requests
from datetime import timedelta
import datetime
import os
from model import get_class
intents=discord.Intents.default()
intents.message_content=True
intents.members=True
IMAGE_DIR="uploads"
os.makedirs(IMAGE_DIR,exist_ok=True)
bot=commands.Bot(command_prefix='$',intents=intents)
admin=False
with open("karaliste.txt", "r", encoding="utf-8") as f:
    blacklist = [line.strip().lower() for line in f if line.strip()]
@bot.event
async def on_ready():
    print(Fore.GREEN+f'Bot başarıyla giriş yaptı! {bot.user}')
    print(Fore.WHITE)
@bot.command("roltest")
async def roltest(ctx, member: discord.Member):
    await ctx.send(
        f"{member.name} rolü: {member.top_role}\n"
        f"Bot rolü: {ctx.guild.me.top_role}"
    )
@bot.command(help="Etiketlediğiniz kullancıyıca zaman aşımı atın. Sadece yöneticiler")
async def timeout(ctx, member: discord.Member):

    # Sunucu sahibi kontrolü
    if member == ctx.guild.owner:
        await ctx.send("❌ Sunucu sahibine timeout atamazsın.")
        return

    # Rol sıralaması kontrolü
    if member.top_role >= ctx.guild.me.top_role:
        await ctx.send("❌ Rol sıralaması yetmiyor.")
        return

    try:
        süre = datetime.timedelta(minutes=9999)
        await member.timeout(discord.utils.utcnow() + süre)
        await ctx.send(f"✅ {member.mention} 1 dakika timeoutlandı.")
    except Exception as e:
        await ctx.send(f"Hata oluştu: {e}")
@bot.command("rol_sirasi")
async def rol_sirasi(ctx, uye: discord.Member):
    await ctx.send(
        f"Bot en yüksek rol: {ctx.guild.me.top_role}\n"
        f"Kullanıcı en yüksek rol: {uye.top_role}"
    )

@bot.command("kimlere_timeout")
async def kimlere_timeout(ctx):
    bot_member = ctx.guild.me
    atilamaz = []

    for member in ctx.guild.members:
        if member.bot:
            continue

        if member == ctx.guild.owner:
            atilamaz.append(f"{member} (Sunucu Sahibi)")
            continue

        if member.top_role >= bot_member.top_role:
            atilamaz.append(f"{member} (Rol yüksek/eşit)")

    if not atilamaz:
        await ctx.send("Bot herkese timeout atabilir 😎")
    else:
        mesaj = "**Timeout Atılamayanlar:**\n" + "\n".join(atilamaz[:2000])
        await ctx.send(mesaj)

@bot.event
async def on_message(message):
    if message.author.bot:
        return

    icerik = message.content.lower()

    # Mesajdaki kelimeleri blacklist ile kontrol et
    if any(re.search(rf"\b{re.escape(word)}\b", icerik) for word in blacklist):
        try:
            await message.delete()  # mesajı sil
            await message.channel.send(f"{message.author.mention}, küfür etmeyin!")

            # Kullanıcıyı 10 dakika timeout
            duration = timedelta(minutes=5)
            await message.author.timeout(duration, reason="Küfür")
        except discord.Forbidden:
            await message.channel.send("Botun kullanıcıyı timeout atma yetkisi yok 😅")
        except discord.HTTPException as e:
            await message.channel.send(f"Timeout atarken hata: {e}")

    await bot.process_commands(message)
@bot.command("merhaba",help="Bot size kendinizi tanıtır")
async def merhaba(ctx):
    await ctx.send(f'Merhaba! Ben {bot.user}, bir Discord sohbet botuyum!')
@bot.command("heh",help="sayı kısmına yazdığınız kadar 'he' der.")
async def heh(ctx, count_heh = 5):
    await ctx.send("he" * count_heh)
@bot.command("yazitura",help="Yazı veya tura der")
async def yazıtura(ctx,times=1):
    await ctx.send(secret_function(times))
@bot.command("joined",help="İstediğiniz kişinin sunucuya ne zaman katıldığını gösterir")
async def joined(ctx, member: discord.Member):
        await ctx.send(f'{member.name} joined {discord.utils.format_dt(member.joined_at)}')
@bot.command("emojispawn",help="3 adet emoji gönderir")
async def emojispawn(ctx):
    await ctx.send(emoji(3))
@bot.command("sifre",help="Bir şifre örneği oluşturun.")
async def sifre(ctx, pass_length):
    try:
        pass_length=int(pass_length)
        if pass_length>=2000:
            await ctx.send("Aga en fazla 2000 karakter")
        await ctx.send(gen_pass(pass_length))
    except OverflowError:
        await ctx.send("Bu şifreyi hafıza kaldıramıyor...")
@bot.command(description='For when you wanna settle the score some other way')
async def choose(ctx, *choices: str):
    """Chooses between multiple choices."""
    await ctx.send(random.choice(choices))
@bot.command("mem",help="Bir mem gönderir.")
async def mem(ctx):
    files=os.listdir("images")
    m=random.choice(files)
    with open(f'images/{m}', 'rb') as f:
        # Dönüştürülen Discord kütüphane dosyasını bu değişkende saklayalım!
        picture = discord.File(f)
    # Daha sonra bu dosyayı bir parametre olarak gönderebiliriz!
    await ctx.send(file=picture)
@bot.command('duck',help="Rastgele bir (seçtiğiniz hayvan) fotoğrafı gönderir.")
async def duck(ctx):
    '''duck komutunu çağırdığımızda, program ordek_resmi_urlsi_al fonksiyonunu çağırır.'''
    image_url = get_duck_image_url()
    await ctx.send(image_url)
@bot.command('dog',help="Rastgele bir (seçtiğiniz hayvan) fotoğrafı gönderir.")
async def dog(ctx):
    image_url=get_dog_image_url()
    await ctx.send(image_url)
@bot.command("cat",help="Rastgele bir (seçtiğiniz hayvan) fotoğrafı gönderir.")
async def cat(ctx):
    image_url=get_cat_image_url()
    await ctx.send(image_url)
@bot.command("cevre_onemi",help="Çevremizin önemini öğrenin!")
async def cevre_onemi(ctx):
    with open('images/gerek.jpg','rb') as g:
        file=discord.File(g)
    await ctx.send(file=file)
    await ctx.send("""Çevremizi temiz tutmamız şimdiki ve gelecektki nesillerimiz için çok önemlidir:
Piller: Geri dönüşüm kutusuna atmak çok önemli çöpe veya yere atmak işe yaramaz, zehirlidir yani canlıların ölümüne sebep olabilir.
Plastikler: Plastikleri yapmak çevreyi çok kirletiyor yani geri dönüşüme atarak üretmeyi azaltabilir hatta durdurabilir! Yere attığınızda ise doğada 100 ile 1000 yıl arası kalır.
Camlar: Doğaya zararı olmaz gibi düşünmeyin, Güneş ışınları ile ormanlar yanabilir yolda yürüyen insanlar zarar görebilir (tabiki hayvanlarda).
Kartonlar: Doğaya zararı yok gibi düşünme ihtimaliniz var ama kartonu üretirken ağaç kesiyoruz, geri dönüşüme atarsak bu azalır.
Çevremizi korumada lütfen sen de yardım et!""")
@bot.command("gd",help="Botun sahip olduğu görsellere erişin.")
async def gd(ctx,gd_ch):
    try:
        with open(f'images/{gd_ch}',"rb") as u:
            file=discord.File(u)
        await ctx.send(file=file)
    except FileNotFoundError:
        await ctx.send("Bulunamadı...")
@bot.command("panda",help="Rastgele bir (seçtiğiniz hayvan) fotoğrafı gönderir.")
async def panda(ctx):
    image_url=get_panda_image_url
    await ctx.send(image_url())
@bot.command("ege",help="Sürpriz!")
async def ege(ctx):
    try:
        with open('images/ege.jpg',"rb") as f:
            file=discord.File(f)
        await ctx.send("Ege ifşa 4K ULTRA HD:")
        await ctx.send(file=file)
    except FileNotFoundError:
        await ctx.send("Aga, Ege kayıp oldu sanırım :(")
@bot.command("enesbaturkaza",help="Enes Batur Kaza FULL HD tam izle premium reklamsız virüssüz")
async def enesbaturkaza(ctx):
    try:
        with open("images/enesbaturbaba.jpg","rb") as f:
            file=discord.File(f)
        await ctx.send(file=file)
    except FileNotFoundError:
        await ctx.send("Hayır Enes Batur kaza falan yapmadı")
@bot.command("roxy",help="Sürpriz!")
async def roxy(ctx):
    with open("images/roxy.jpg","rb") as f:
        file=discord.File(f)
    await ctx.send(file=file)
@bot.command("love",help="Etiketlediğiniz kişinin sizi ne kadar sevdiğini öğrenin.")
async def love(ctx,member:discord.Member):
    try:
        await ctx.send(f"{member.name} ile sevginiz:")
        sevgi=str(random.randint(0,100))
        await ctx.send("%"+sevgi)
    except:
        await ctx.send("patates kızartması")
@bot.command(help="Görselinizi yapay zeka ile analiz edin!")
async def analize(ctx):
    if ctx.message.attachments:
        for i in ctx.message.attachments:
            file_name=i.filename
            file_path=os.path.join(IMAGE_DIR,file_name)
            await i.save(file_path)
            await ctx.send("Görseliniz başarıyla kayıt edildi"+"!"*random.randint(1,50))
            class_name,score=get_class(file_path)
            await ctx.send(f"""Sonuçlar:
Görselinizin sınıfı: {class_name}
Doğruluk oranı: {score}""")
            if class_name.lower()=="roblox":
                await ctx.send("İçinde başka kişilerin yaptığı oyunlarla hemen oynanabilir oyun kütüphanesi gibi.")
            if class_name.lower()=="rpg":
                await ctx.send("**RPG (Rol Yapma Oyunu)**, oyuncunun bir karakteri kontrol ettiği ve o karakterin hikâyesini ilerlettiği oyun türüdür. Oyuncu görevler yapar, karakterini geliştirir ve oyun dünyasında farklı seçimler yaparak macerayı ilerletir. 🎮")
            if class_name.lower()=="action-game":
                await ctx.send("Aksiyon oyunları maceralı, oraya buraya kaçtığımız genellikle çatışmalı oyunlardır.")
            if class_name.lower()=="race-game":
                await ctx.send("Muhtemelen ebeveynlerin en iyi oyun türüdür yarış oyunları, bir arabayla diğer sürcülere karşı 1. olmak için yarıştığınız oyun türüdür.")
    else:
        await ctx.send("Görsel bulunamadı, komutun çalışması için lütfen mesajınıza bir görsel ekleyin...")
# @bot.command("gizli")
# async def gizli(ctx):
#     with open()
bot.run("#")