import random,requests
def gen_pass(pass_length):
    global password
    elements="abcdefghijklmnoprstuvyzxqw+-/*!$?=0<>0123456789"
    password=""
    for i in range(pass_length):
        password+=random.choice(elements)
    return password
emojis="😂🫠☺️😉🤫🥳🥺💀❤️😨"
willwrite=""
def emoji(hm_emoji):
    global ch_emoji,willwrite,emojis
    for i in range(hm_emoji):
        ch_emoji=random.choice(emojis)
        willwrite+=ch_emoji
        if len(willwrite)>3:
            willwrite=""
        if len(willwrite)<1:
            willwrite="😨"
    return willwrite
def double_letter (str):
    result = ''
    for letter in str:
        result += letter * 2
    return result
def get_duck_image_url():    
    url = 'https://random-d.uk/api/random'
    res = requests.get(url)
    data = res.json()
    return data['url']
def get_dog_image_url():
    url='https://dog.ceo/api/breeds/image/random'
    res=requests.get(url)
    data=res.json()
    return data['message']
def get_cat_image_url():
    url="https://api.thecatapi.com/v1/images/search"
    res=requests.get(url)
    data=res.json()
    return data[0]['url']
def get_panda_image_url():
    url="https://api.some-random-api.com/img/panda"
    res=requests.get(url)
    data=res.json()
    return data["link"]

def secret_function (times=1):
    sonuclar=[]
    for i in range(times):
        global choose
        choos=random.randint(0,1)
        choose=""
        if choos==0:
            choose="yazı"
        else:
            choose="tura"
        sonuclar.append(choose)
    return sonuclar


print(double_letter("Hello"))
print(secret_function())